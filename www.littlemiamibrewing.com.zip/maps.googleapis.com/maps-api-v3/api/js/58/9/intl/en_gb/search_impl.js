google.maps.__gjsload__('search_impl', function(_) {
    var Jwb = function(a, b) {
            _.vh(a.Gg, 1, b)
        },
        Kwb = function(a, b) {
            _.vh(a.Gg, 3, b)
        },
        Owb = function(a, b, c) {
            var d = new Lwb;
            d = _.PG(d);
            c.wr = d.load.bind(d);
            c.clickable = a.get("clickable") !== !1;
            _.WWa(c, _.qQ(b));
            b = [];
            b.push(_.Pk(c, "click", Mwb.bind(null, a)));
            for (const e of ["mouseover", "mouseout", "mousemove"]) b.push(_.Pk(c, e, Nwb.bind(null, a, e)));
            b.push(_.Pk(a, "clickable_changed", () => {
                a.Eg.clickable = a.get("clickable") !== !1
            }));
            a.Fg = b
        },
        Mwb = function(a, b, c, d, e) {
            let f = null;
            if (e && (f = {
                    status: e.getStatus()
                }, e.getStatus() === 0)) {
                f.location =
                    _.X(e.Gg, 2) ? new _.Bk(_.at(_.J(e.Gg, 2, _.gt).Gg, 1), _.at(_.J(e.Gg, 2, _.gt).Gg, 2)) : null;
                const g = {};
                f.fields = g;
                const h = _.Ui(e.Gg, 3);
                for (let k = 0; k < h; ++k) {
                    const m = _.mr(e.Gg, 3, _.CQ, k);
                    g[m.getKey()] = m.getValue()
                }
            }
            _.al(a, "click", b, c, d, f)
        },
        Nwb = function(a, b, c, d, e, f, g) {
            let h = null;
            f && (h = {
                title: f[1].title,
                snippet: f[1].snippet
            });
            _.al(a, b, c, d, e, h, g)
        },
        Pwb = function() {},
        Qwb = class {},
        Rwb = class extends _.U {
            constructor() {
                super()
            }
            Ni() {
                return _.mj(this.Gg, 2)
            }
        },
        Swb = [_.M, , , _.ip, _.nYa];
    var Twb = class extends _.U {
        constructor(a) {
            super(a)
        }
        getStatus() {
            return _.H(this.Gg, 1, -1)
        }
        getLocation() {
            return _.gj(this.Gg, 2, _.gt)
        }
    };
    var Lwb = class {
        constructor() {
            var a = _.Ao,
                b = _.zo;
            this.Eg = _.nj;
            this.fetch = _.yx.bind(Qwb, a, _.oy + "/maps/api/js/LayersService.GetFeature", b)
        }
        load(a, b) {
            function c(e) {
                b(new Twb(e))
            }
            const d = new Rwb;
            Jwb(d, a.layerId.split("|")[0]);
            _.vh(d.Gg, 2, a.featureId);
            Kwb(d, this.Eg.Eg().Eg());
            for (const e in a.parameters) {
                const f = _.jj(d.Gg, 4, _.CQ);
                _.vh(f.Gg, 1, e);
                _.vh(f.Gg, 2, a.parameters[e])
            }
            a = _.Zi(d, Swb, 1);
            this.fetch(a, c, c);
            return a
        }
        cancel() {
            throw Error("Not implemented");
        }
    };
    Pwb.prototype.GG = function(a) {
        if (_.Cn[15]) {
            var b = a.Bl;
            const c = a.Bl = a.getMap();
            b && a.Eg && (a.Hg ? (b = b.__gm.ak, b.set(b.get().Qn(a.Eg))) : a.Eg && _.wXa(a.Eg, b) && ((a.Fg || []).forEach(_.Rk), a.Fg = null));
            if (c) {
                b = new _.pw;
                const d = a.get("layerId").split("|");
                b.layerId = d[0];
                for (let e = 1; e < d.length; ++e) {
                    const [f, ...g] = d[e].split(":");
                    b.parameters[f] = g.join(":")
                }
                a.get("spotlightDescription") && (b.spotlightDescription = new _.Dw(a.get("spotlightDescription")));
                a.get("paintExperimentIds") && (b.paintExperimentIds = a.get("paintExperimentIds").slice(0));
                a.get("styler") && (b.styler = new _.vw(a.get("styler")));
                a.get("roadmapStyler") && (b.roadmapStyler = new _.vw(a.get("roadmapStyler")));
                a.get("travelMapRequest") && (b.travelMapRequest = new _.Foa(a.get("travelMapRequest")));
                a.get("mapsApiLayer") && (b.mapsApiLayer = new _.qw(a.get("mapsApiLayer")));
                a.get("mapFeatures") && (b.mapFeatures = a.get("mapFeatures"));
                a.get("clickableCities") && (b.clickableCities = a.get("clickableCities"));
                a.get("searchPipeMetadata") && (b.searchPipeMetadata = new _.Yx(a.get("searchPipeMetadata")));
                a.get("gmmContextPipeMetadata") && (b.gmmContextPipeMetadata = new _.Sma(a.get("gmmContextPipeMetadata")));
                a.get("overlayLayer") && (b.overlayLayer = new _.Ew(a.get("overlayLayer")));
                a.get("caseExperimentIds") && (b.caseExperimentIds = a.get("caseExperimentIds").slice(0));
                a.get("boostMapExperimentIds") && (b.boostMapExperimentIds = a.get("boostMapExperimentIds").slice(0));
                a.get("airQualityPipeMetadata") && (b.airQualityPipeMetadata = new _.joa(a.get("airQualityPipeMetadata")));
                a.get("directionsPipeParameters") && (b.directionsPipeParameters =
                    new _.Ly(a.get("directionsPipeParameters")));
                a.get("clientSignalPipeMetadata") && (b.clientSignalPipeMetadata = new _.Ama(a.get("clientSignalPipeMetadata")));
                b.darkLaunch = !!a.get("darkLaunch");
                a.Eg = b;
                a.Hg = a.get("renderOnBaseMap");
                a.Hg ? (a = c.__gm.ak, a.set(_.Cr(a.get(), b))) : Owb(a, c, b);
                _.Ml(c, "Lg");
                _.L(c, 148282)
            }
        }
    };
    _.Jj("search_impl", new Pwb);
});