google.maps.__gjsload__('search', function(_) {
    var esa = function() {},
        VA = function(a) {
            this.setValues(a);
            _.Ij("search_impl")
        },
        gsa = function(a) {
            let b = _.im,
                c = -1;
            a.tiles.forEach(e => {
                e.zoom > c && (b = e.fi, c = e.zoom)
            });
            if (c === -1) return [];
            const d = [];
            a.Fu().forEach(e => {
                e.a && e.a.length >= 2 && d.push(new fsa(e, b, c))
            });
            return d
        },
        hsa = function(a) {
            const b = [];
            a.data.forEach(c => {
                b.push(...gsa(c))
            });
            return b
        };
    _.Ha(esa, _.il);
    var isa = {
            ["1"]: {}
        },
        fsa = class {
            constructor(a, b, c) {
                this.kn = b;
                this.zoom = c;
                this.bounds = this.anchor = null;
                this.Eg = isa;
                this.source = a;
                this.featureId = this.source.id || "0";
                this.infoWindowOffset = (this.source.io || []).length === 2 ? new google.maps.Point(this.source.io[0], this.source.io[1]) : null
            }
            getAnchor() {
                if (!this.anchor) {
                    const a = 1 << this.zoom;
                    this.anchor = _.Hm(new _.Sm((this.kn.x * 256 + this.source.a[0]) / a, (this.kn.y * 256 + this.source.a[1]) / a)).toJSON()
                }
                return this.anchor
            }
            getCompleteBounds() {
                return this.getBounds().reduce((a,
                    b) => {
                    a.extendByBounds(b);
                    return a
                }, _.Lm(0, 0, 0, 0))
            }
            getBounds() {
                if (this.bounds === null) {
                    this.bounds = [];
                    const a = this.source.bb || [];
                    if (a.length % 4 === 0)
                        for (let b = 0; b < a.length; b += 4) {
                            const c = this.bounds[this.bounds.length - 1],
                                d = _.Lm(a[b], a[b + 1], a[b + 2], a[b + 3]);
                            c && c.equals(d) || this.bounds.push(d)
                        }
                }
                return [...this.bounds]
            }
            getExtendedContent(a) {
                if (this.Eg === isa) try {
                    this.Eg = this.source.c ? JSON.parse(this.source.c) : {}
                } catch (b) {
                    this.Eg = {}
                }
                return this.Eg[a] ? ? {}
            }
            getFeatureName() {
                return this.getExtendedContent("1") ? .title ? ?
                    null
            }
            isTransitStation() {
                return this.getExtendedContent("1") ? .is_transit_station ? ? !1
            }
        };
    var jsa = new WeakSet;
    _.Ha(VA, esa);
    VA.prototype.changed = function() {
        const a = this;
        var b = this.get("map");
        let c = null;
        b && (c = b.__gm, b = c.get("blockingLayerCount") || 0, c.set("blockingLayerCount", b + 1), c.set("disableLabelingHysteresis", this.get("disableLabelingHysteresis")), c.set("tilePrefetchEnabled", this.get("tilePrefetchEnabled")));
        _.Ij("search_impl").then(d => {
            d.GG(a);
            c && (d = c.get("blockingLayerCount") || 0, c.set("blockingLayerCount", d - 1))
        })
    };
    VA.enableFeatureMapEventsRasterOnly = function(a) {
        if (_.Cn[15]) {
            var b = a.__gm.Xg;
            if (!jsa.has(a)) {
                jsa.add(a);
                var c = [],
                    d = (f, g) => {
                        f = gsa(f);
                        f.length && _.al(a, g, f)
                    },
                    e = () => {
                        for (; c.length > 0;) c.pop().remove();
                        b.forEach(f => {
                            if (f = f.data) c.push(_.Pk(f, "insert", g => d(g, "addfeatures"))), c.push(_.Pk(f, "remove", g => d(g, "removefeatures")))
                        })
                    };
                b.addListener("insert_at", e);
                b.addListener("remove_at", e);
                b.addListener("set_at", e);
                e()
            }(() => {
                const f = [];
                b.forEach(g => {
                    f.push(...hsa(g))
                });
                f.length && _.al(a, "addfeatures", f)
            })()
        }
    };
    _.Fa("module$contents$mapsapi$onionLayers$search$googleLayer_GoogleLayer.enableFeatureMapEventsRasterOnly", VA.enableFeatureMapEventsRasterOnly);
    _.Il(VA.prototype, {
        map: _.Lp
    });
    _.pa.google.maps.search = {
        GoogleLayer: VA
    };
    _.Jj("search", {});
});